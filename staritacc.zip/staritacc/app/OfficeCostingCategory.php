<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OfficeCostingCategory extends Model
{
    //
}
